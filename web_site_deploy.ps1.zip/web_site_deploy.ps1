configuration Sample_xWebsite_NewWebsite 
{ 
    param 
    ( 
        # Target nodes to apply the configuration 
        [string[]]$NodeName = 'localhost' 
    ) 
    # Import the module that defines custom resources 
    Import-DscResource -Module xWebAdministration 
    
    Node $NodeName 
    { 
        # Install the IIS role 
        WindowsFeature IIS 
        { 
            Ensure          = "Present" 
            Name            = "Web-Server" 
        } 
        # Install the ASP .NET 4.5 role 
        WindowsFeature AspNet45 
        { 
            Ensure          = "Present" 
            Name            = "Web-Asp-Net45" 
        }
        WindowsFeature WebServerManagementConsole
        {
            Name = "Web-Mgmt-Console"
            Ensure = "Present"
        }
       <# # Install the ASP .NET App Initialization (for autoStart)  
        WindowsFeature Web-AppInit  
        {  
            Ensure          = 'Present'  
            Name            = 'Web-AppInit'  
            DependsOn       = '[WindowsFeature]AspNet45'  
        }

        # Start aspnet session state service is running
        Service aspnet_state
        {
            Name        = "aspnet_state"
            StartupType = "Automatic"
            State       = "Running"
            DependsOn   = '[WindowsFeature]AspNet45'  
        }
       
        xWaitForService aspnet_state-Wait
        {
            Name         = 'aspnet_state'
            State        = 'Running'
            DependsOn    = '[Service]aspnet_state'  
        }#>
        # Stop the default website 
        xWebsite DefaultSite  
        { 
            Ensure          = "Present" 
            Name            = "Default Web Site" 
            State           = "Stopped" 
            PhysicalPath    = "C:\inetpub\wwwroot" 
            DependsOn       = "[WindowsFeature]IIS" 
        } 
        # Copy the website content 
        File WebContent 
        { 
            Ensure          = "Present" 
            SourcePath      = "C:\Program Files\WindowsPowerShell\Modules\xWebAdministration\mysite" 
            DestinationPath = "C:\inetpub\mywebsite"
            Recurse         = $true 
            Type            = "Directory" 
            DependsOn       = "[WindowsFeature]AspNet45" 
        }        
        # Create the new Website with HTTPS 
        xWebsite NewWebsite 
        { 
            Ensure          = "Present" 
            Name            = "myWebsite" 
            State           = "Started" 
            PhysicalPath    = "C:\inetpub\mywebsite"
            DependsOn       = "[File]WebContent" 
        } 
    } 
} 